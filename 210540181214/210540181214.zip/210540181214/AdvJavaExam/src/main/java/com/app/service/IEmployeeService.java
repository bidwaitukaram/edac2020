package com.app.service;

import com.app.pojos.Employee;

public interface IEmployeeService {
	String hireEmployee(Employee employee,String deptName);
}
