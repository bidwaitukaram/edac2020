package com.app.dao;

import java.util.List;

import com.app.pojos.Department;

public interface IDepartmentDao {

	public List<Department> fetchAllDepartments();
}
